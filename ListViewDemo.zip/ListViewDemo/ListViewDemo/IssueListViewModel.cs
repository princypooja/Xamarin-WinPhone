﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ListViewDemo
{
    public class IssueListViewModel : ViewModelBase
    {
        public IssueListViewModel()
        {
            RequestSuccessful(IssueListData.GetIssueListData());
        }
        public void GetDepartmentRefreshData()
        {
            RequestSuccessful(IssueListData.GetIssueListData());

        }
        public void GetOwnRefreshData()
        {
            RequestSuccessful(IssueListData.GetIssueListData());

        }
        public static IssueListViewModel issueVMInstance;
        public static IssueListViewModel GetInstance()
        {
            if (issueVMInstance == null)
            {
                
                issueVMInstance = new IssueListViewModel();

            }
            return issueVMInstance;
        }


        public void LoadOnDemandDepartmentList(IssueModel item)
        {
            int count = IssueDepartmentList.Count;
            int index = IssueDepartmentList.IndexOf(item);
            if (count > 0)
            {
                if (count - 1 <= index && !IsLoadMoreDept && !IsRefreshDept)
                {
                    IsLoadMoreDept = true;
                  
                   
                    RequestSuccessful(IssueListData.GetIssueListData());
                }
            }
        }
       
     
        public void RequestSuccessful(object successResponse)
        {
            try
            {
                if (successResponse != null)
                {
                    var list = (List<IssueModel>)successResponse;
                    if (list != null)
                    {
                       
                        foreach (IssueModel issue in list)
                        {
                           
                            if (!string.IsNullOrEmpty(issue.description))
                                issue.ShortDescription = issue.id + "," + issue.description;
                            else
                                issue.ShortDescription = issue.id + "," + issue.title;
                            if (string.IsNullOrEmpty(issue.imageName))
                            {
                                issue.imageName = "picture.png";
                            }
                           
                            if (!string.IsNullOrEmpty(issue.handlerID.ToString()) && issue.handlerID != 0)

                            {
                                issue.displayAssign = true;
                            }
                            else
                                issue.displayAssign = false;
                          /*  try
                            {
                                if (!string.IsNullOrEmpty(issue.createdDate))
                                    issue.createdDate = (DateTime.ParseExact(issue.createdDate, "MM/dd/yyyy HH:mm:ss", new CultureInfo("en-US"))).ToString("dd-MMM-yyyy");
                            }
                            catch (Exception ex) { }*/
                        }
 
                            if (IsLoadMoreDept )
                            {
                                foreach (IssueModel issue in list.ToObservableCollection<IssueModel>())
                                {
                                    
                                    IssueDepartmentList.Add(issue);
                                    IsLoadMoreDept = false;
                                }

                            }
                            else
                            {
                                //TemporaryDeptIssueList = list;
                                IssueDepartmentList = list.ToObservableCollection<IssueModel>();

                            }
                            IsActiveDepartmentLoader = false;
                            if (IssueDepartmentList.Count >= 5)
                                IsRefreshDept = false;
                        
                       
                    }
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
                  }
        }
       
        #region Properties


        private ObservableCollection<IssueModel> _issueList;
        public ObservableCollection<IssueModel> IssueDepartmentList
        {
            get { return _issueList; }
            set
            {
                if (value == _issueList)
                    return;
                _issueList = value;
                OnPropertyChanged("IssueDepartmentList");
            }
        }

        private ObservableCollection<IssueModel> _issueOwnList;
        public ObservableCollection<IssueModel> IssueOwnList
        {
            get { return _issueOwnList; }
            set
            {
                if (value == _issueOwnList)
                    return;
                _issueOwnList = value;
                OnPropertyChanged("IssueOwnList");
            }
        }
        private bool _ownListVisible;
        public bool OwnListVisible
        {
            get { return _ownListVisible; }
            set
            {
                _ownListVisible = value;
                if (_ownListVisible)
                {
                    DepartmentVisible = false;
                }
                else
                {
                    DepartmentVisible = true;
                }
                OnPropertyChanged("OwnListVisible");
            }
        }
        private bool _departmentVisible;
        public bool DepartmentVisible
        {
            get { return _departmentVisible; }
            set
            {
                _departmentVisible = value;
                OnPropertyChanged("DepartmentVisible");
            }
        }

        private bool _isActiveOwnLoader;
        public bool IsActiveOwnLoader
        {
            get { return _isActiveOwnLoader; }
            set
            {
                _isActiveOwnLoader = value;
                OnPropertyChanged("IsActiveOwnLoader");
            }
        }
        private bool _isActiveDepartmentLoader;
        public bool IsActiveDepartmentLoader
        {
            get { return _isActiveDepartmentLoader; }
            set
            {
                _isActiveDepartmentLoader = value;
                OnPropertyChanged("IsActiveDepartmentLoader");
            }
        }
        private bool _isRefreshDept;
        public bool IsRefreshDept
        {
            get { return _isRefreshDept; }
            set
            {
                _isRefreshDept = value;
                OnPropertyChanged("IsRefreshDept");
            }
        }
        private bool _isRefreshOwn;
        public bool IsRefreshOwn
        {
            get { return _isRefreshOwn; }
            set
            {
                _isRefreshOwn = value;
                OnPropertyChanged("IsRefreshOwn");
            }
        }

        public string IssueId { get; set; }

        private string _title;
        public string IssueTitle
        {
            get { return _title; }
            set
            {
                _title = value;
                OnPropertyChanged("IssueTitle");
            }
        }

        public double latitude { get; set; }
        public double longitude { get; set; }
        public bool isSupported { get; set; }
        private string _description;
        public string Description
        {
            get { return _description; }
            set
            {
                _description = value;
                OnPropertyChanged("Description");
            }
        }

        private string _address;
        public string Address
        {
            get { return _address; }
            set
            {
                _address = value;
                OnPropertyChanged("Address");
            }
        }
        private string _totalSupport;
        public string TotalSupport
        {
            get { return _totalSupport; }
            set
            {
                _totalSupport = value;
                OnPropertyChanged("TotalSupport");
            }
        }

        private string _totalComment;
        public string TotalComment
        {
            get { return _totalComment; }
            set
            {
                _totalComment = value;
                OnPropertyChanged("TotalComment");
            }
        }
        public int publicComment { get; set; }
        private string _status;
        public string Status
        {
            get { return _status; }
            set
            {
                _status = value;
                OnPropertyChanged("Status");
            }
        }
        public object acknowledgedDate { get; set; }
        public object resolvedDate { get; set; }
        private string _createdDate;
        public string CreatedDate
        {
            get { return _createdDate; }
            set
            {
                _createdDate = value;
                OnPropertyChanged("CreatedDate");
            }
        }
        private bool _loadMoreOwn = false;
        public bool IsLoadMoreOwn
        {
            get { return _loadMoreOwn; }
            set
            {
                _loadMoreOwn = value;
                OnPropertyChanged("LoadMoreOwn");
            }
        }
        private bool _loadMoreDept = false;
        public bool IsLoadMoreDept
        {
            get { return _loadMoreDept; }
            set
            {
                _loadMoreDept = value;
                OnPropertyChanged("LoadMoreDept");
            }
        }
        private string _imageName;
        public string IssueImage
        {
            get { return _imageName; }
            set
            {

                _imageName = value;
                OnPropertyChanged("IssueImage");
            }
        }
        private string _citizenName;
        public string CitizenName
        {
            get { return _citizenName; }
            set
            {
                _citizenName = value;
                OnPropertyChanged("CitizenName");
            }
        }
        public int categoryID { get; set; }
        private string _category;
        public string IssueType
        {
            get { return _category; }
            set
            {
                _category = value;
                OnPropertyChanged("IssueType");
            }
        }
        public object CategoryInternalName { get; set; }
        public int departmentID { get; set; }
        public int handlerID { get; set; }
        public object denyReason { get; set; }
        public int userID { get; set; }

        private string _citizenEmail;
        public string CitizenEmail
        {
            get { return _citizenEmail; }
            set
            {
                _citizenEmail = value;
                OnPropertyChanged("CitizenEmail");
            }
        }
        private string _citizenMobileNo;
        public string CitizenMobileNo
        {
            get { return _citizenMobileNo; }
            set
            {
                _citizenMobileNo = value;
                OnPropertyChanged("CitizenMobileNo");
            }
        }
        private string _citizenLocation;
        public string CitizenLocation
        {
            get { return _citizenLocation; }
            set
            {
                _citizenLocation = value;
                OnPropertyChanged("CitizenLocation");
            }
        }
        #endregion
    }
}