﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ListViewDemo
{
    public class IssueModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        private ImageSource imgSource;
        public ImageSource ImageName
        {
            get { return imgSource; }
            set
            {
                imgSource = value;
                OnPropertyChanged("ImageName");

            }
        }
        private bool _imageVisibility;
        public bool ImageVisibility
        {
            get { return _imageVisibility; }
            set
            {
                _imageVisibility = value;
                OnPropertyChanged("ImageVisibility");
            }
        }
        private bool _imageDefaultVisibility;
        public bool ImageDefaultVisibility
        {
            get { return _imageDefaultVisibility; }
            set
            {
                _imageDefaultVisibility = value;
                OnPropertyChanged("ImageDefaultVisibility");
            }
        }
        public int index;
        public int id { get; set; }
        public string title { get; set; }
        public double latitude { get; set; }
        public double longitude { get; set; }
        public bool isSupported { get; set; }
        public string description { get; set; }
        public string ShortDescription { get; set; }
        public string address { get; set; }
        public int totalSupport { get; set; }
        public int totalComment { get; set; }
        public int publicComment { get; set; }
        public int status { get; set; }
        public bool displayAssign { get; set; }
        public object acknowledgedDate { get; set; }
        public object resolvedDate { get; set; }
        public string createdDate { get; set; }
        public string imageName { get; set; }
        public string LargeImageName { get; set; }
        public int categoryID { get; set; }
        public string Category { get; set; }
        public object CategoryInternalName { get; set; }
        public int departmentID { get; set; }
        public int handlerID { get; set; }
        public object denyReason { get; set; }
        public int userID { get; set; }

        public string DepartmentName { get; set; }

        public string handlerName { get; set; }
        public string handlerEmail { get; set; }

        public int handlerProgressStatus { get; set; }
        public IssueModel()
        {
            imageName = "picture.png";
            ImageVisibility = false;
            ImageDefaultVisibility = true;
        }

    }
}
