﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Xamarin.Forms;

namespace ListViewDemo
{
    public partial class IssueListView : ContentPage
    {
        public IssueListView()
        {

            try
            {
                InitializeComponent();
                this.BindingContext = IssueListViewModel.GetInstance();
                AddEvents();
            }
            catch (Exception ex)
            {
                // DialogMessage.DisplayInformationAlert("Fail", ex.ToString(), Messages.AlertOK);
            }
        }

        private void AddEvents()
        {

            var tapGestureRecognizerForDept = new TapGestureRecognizer();
            tapGestureRecognizerForDept.Tapped += BtnDept_Tapped;
            BtnDept.GestureRecognizers.Add(tapGestureRecognizerForDept);
            var tapGestureRecognizerForOwn = new TapGestureRecognizer();
            tapGestureRecognizerForOwn.Tapped += BtnOwn_Tapped;
            BtnOwn.GestureRecognizers.Add(tapGestureRecognizerForOwn);
               }
       
        void BtnDept_Tapped(object sender, EventArgs args)
        {

           IssueListViewModel.GetInstance().GetDepartmentRefreshData();
        }
        void BtnOwn_Tapped(object sender, EventArgs args)
        {
            IssueListViewModel.GetInstance().GetOwnRefreshData();
        }
        private void DepartmentList_ItemAppearing(object sender, ItemVisibilityEventArgs e)
        {
            try
            {
                IssueListViewModel.GetInstance().LoadOnDemandDepartmentList((IssueModel)e.Item);
            }
            catch (Exception ex)
            {
               
            }
        }

        private void DepartmentList_ItemDisappearing(object sender, EventArgs e)
        {
            //DepartmentList.Refreshing += DepartmentList_Refreshing;
            //  if (sender is ViewCell)
            // {
            ViewCell cell = (ViewCell)sender;
            //    Xamarin.Forms.Image img = cell.FindByName<Xamarin.Forms.Image>("ImgDept");
            //   img.Source = null;


            cell.ContextActions.Clear();
            cell = null;
            GC.Collect();
            //   }  
        }

        private void DepartmentList_Refreshing(object sender, EventArgs e)
        {

        }

        private void DepartmentList_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            
        }

        private void OwnList_ItemAppearing(object sender, ItemVisibilityEventArgs e)
        {
          //  IssueListViewModel.GetInstance().LoadOnDemandOwnList((IssueModel)e.Item);
        }

        private void OwnList_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
           

        }


    }
}
